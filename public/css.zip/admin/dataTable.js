$(document).ready(function () {
    $('.userdatatable').DataTable();
});